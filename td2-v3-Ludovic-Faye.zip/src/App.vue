<template>

  <header>
    <div class="flex">
      <Logo></Logo>
    <nav class="flex w-full justify-between bg-white/40 p-4 text-gray-900 items-center">    
      <div class="flex gap-4 md:w-auto md:items-center">        
        <div class="hidden gap-6 md:flex ">
          <a class="mr-4 block md:text-black md:font-bold" href="/link">Rent</a>
          <a class="mr-4 block md:text-black md:font-bold" href="/link">Buy</a>
          <a class="mr-4 block md:text-black md:font-bold" href="/link">Sell</a>
          <a class="mr-4 block md:text-black md:font-bold" href="/link">Manage property</a>
          <a class="mr-4 block md:text-black md:font-bold" href="/link">Ressources</a>
        </div>
      </div>
      <div class="hidden text-sm md:flex">
        <a class="ml-2 rounded border border-indigo-500 bg-white p-2 font-bold leading-none text-indigo-500 hover:border-transparent hover:bg-gray-100" href="/auth/signin">Login</a>
        <a class="ml-2 rounded border border-indigo-600 bg-indigo-500 p-2 font-bold leading-none text-gray-100 hover:border-transparent hover:bg-teal-600" href="/auth/signup">Sign up</a>        
      </div>
      <Menu class="sm:flex md:hidden " />
    </nav>
    </div>
    <hr class="bg-indigo-200 border-color-100 border-solid border-[1.5px]"/>
  </header>

  <SearchBar></SearchBar>

  <div class="grid grid-flow-row-dense grid-cols-[repeat(auto-fit,minmax(300px,1fr))]">
    <cardExFigma
    image="assets\images\maison1.png">
    </cardExFigma>
    <cardExFigma
      :price="4300"
      nom="Tarpon bay"
      adresse="103 Lake Shores, Michigan, IN"
      :favoris="true"
      :numberBeds="4"
      :numberBathrooms="4"
      dimensions="6x7.5 m²"
      image="assets\images\maison2.png"
    ></cardExFigma>
    <cardExFigma
      :price="4300"
      nom="Tarpon bay"
      adresse="103 Lake Shores, Michigan, IN"
      :favoris="true"
      :numberBeds="4"
      :numberBathrooms="4"
      dimensions="6x7.5 m²"
      image="assets\images\maison2.png"
    ></cardExFigma>
    <cardExFigma
      :price="4300"
      nom="Tarpon bay"
      adresse="103 Lake Shores, Michigan, IN"
      :favoris="true"
      :numberBeds="4"
      :numberBathrooms="4"
      dimensions="6x7.5 m²"
      image="assets\images\maison2.png"
    ></cardExFigma>
    <cardExFigma
      :price="4300"
      nom="Tarpon bay"
      adresse="103 Lake Shores, Michigan, IN"
      :favoris="true"
      :numberBeds="4"
      :numberBathrooms="4"
      dimensions="6x7.5 m²"
      image="assets\images\maison2.png"
    ></cardExFigma>
    <cardExFigma
      :price="4300"
      nom="Tarpon bay"
      adresse="103 Lake Shores, Michigan, IN"
      :favoris="true"
      :numberBeds="4"
      :numberBathrooms="4"
      dimensions="6x7.5 m²"
      image="assets\images\maison2.png"
    ></cardExFigma>
    <cardExFigma
      :price="4300"
      nom="Tarpon bay"
      adresse="103 Lake Shores, Michigan, IN"
      :favoris="true"
      :numberBeds="4"
      :numberBathrooms="4"
      dimensions="6x7.5 m²"
      image="assets\images\maison2.png"
    ></cardExFigma>
    <cardExFigma
      :price="4300"
      nom="Tarpon bay"
      adresse="103 Lake Shores, Michigan, IN"
      :favoris="true"
      :numberBeds="4"
      :numberBathrooms="4"
      dimensions="6x7.5 m²"
      image="assets\images\maison2.png"
    ></cardExFigma>
    <cardExFigma
      :price="4300"
      nom="Tarpon bay"
      adresse="103 Lake Shores, Michigan, IN"
      :favoris="true"
      :numberBeds="4"
      :numberBathrooms="4"
      dimensions="6x7.5 m²"
      image="assets\images\maison2.png"
    ></cardExFigma>
    <cardExFigma
      :price="4300"
      nom="Tarpon bay"
      adresse="103 Lake Shores, Michigan, IN"
      :favoris="true"
      :numberBeds="4"
      :numberBathrooms="4"
      dimensions="6x7.5 m²"
      image="assets\images\maison2.png"
    ></cardExFigma>
    <cardExFigma
      :price="4300"
      nom="Tarpon bay"
      adresse="103 Lake Shores, Michigan, IN"
      :favoris="true"
      :numberBeds="4"
      :numberBathrooms="4"
      dimensions="6x7.5 m²"
      image="assets\images\maison2.png"
    ></cardExFigma>
    <cardExFigma
      :price="4300"
      nom="Tarpon bay"
      adresse="103 Lake Shores, Michigan, IN"
      :favoris="true"
      :numberBeds="4"
      :numberBathrooms="4"
      dimensions="6x7.5 m²"
      image="assets\images\maison2.png"
    ></cardExFigma>
    <cardExFigma
      :price="4300"
      nom="Tarpon bay"
      adresse="103 Lake Shores, Michigan, IN"
      :favoris="true"
      :numberBeds="4"
      :numberBathrooms="4"
      dimensions="6x7.5 m²"
      image="assets\images\maison2.png"
    ></cardExFigma>
  </div>

  <Footer></Footer>
</template>


<script >
export default {
  components: { CardExFigma, Bouton, Logo, Menu, Ligne, Footer, SearchBar, },
  name: "App",
};
import CardExFigma from "./component/CardExFigma.vue";
import Bouton from "./component/Bouton.vue";
import Logo from "./component/Logo.vue";
import Menu from "./component/Menu.vue";
import Ligne from "./component/Ligne.vue";
import Footer from "./component/Footer.vue";
import SearchBar from "./component/SearchBar.vue"

</script>