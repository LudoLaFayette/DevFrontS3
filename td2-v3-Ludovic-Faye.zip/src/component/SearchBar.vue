<template>
  <div class="bg-indigo-50 lg:flex lg:justify-between">
    <h1 class="m-4 mt-14 text-center text-4xl font-bold ">Search properties to rent</h1>

    <div class="mx-6 mt-14 flex justify-between rounded-lg border-2 items-center border-indigo-100 bg-white px-2 lg:ml-48 lg:flex-1 lg:pt-2 lg:pb-2 ">
      <p class="lg: text-left font-medium text-gray-900">Search with Search Bar</p>

      <FlecheBas class="my-1 rounded-xl bg-indigo-100 "></FlecheBas>
    </div>
  </div>

  <div class="mx-6 mt-10 flex justify-between rounded-lg bg-white lg:hidden border-indigo-50 border-solid border">
    <p class="px-2 py-4 font-medium text-gray-500">Search location</p>

    <Search class="m-2 bg-indigo-500 p-3"></Search>
  </div>

  <div class="lg: mx-12 hidden lg:mt-8 lg:grid lg:grid-cols-4 bg-indigo-50">
    <div class="m-2 border-r-2">
      <p class="text-gray-500">Location</p>
      <p class="font-semibold">New York, USA</p>
    </div>

    <div class="m-2 border-r-2">
      <p class="text-gray-500">When</p>
      <p class="font-semibold">Select Move-in Date</p>
    </div>

    <div class="m-2 border-r-2">
      <p class="text-gray-500">Price</p>
      <p class="font-semibold">$500-$2,500</p>
    </div>

    <div class="pl-28">
      <p class="m-2 rounded-lg bg-indigo-500 px-5 py-4 pl-6 text-center text-white">Search</p>
    </div>
  </div>
</template>

<script >
export default {
  components: { Search, FlecheBas },
};
import Search from "./Search.vue";
import FlecheBas from "./FlecheBas.vue";
</script>