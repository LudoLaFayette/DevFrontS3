<template>
    <footer>
  <div class="w-[1280px] h-[566px] relative overflow-hidden bg-white">
  <div class="w-[986px] h-[25px]">
    <div
      class="flex justify-start items-start w-56 absolute left-[908.5px] top-[511.5px] opacity-30 gap-10"
    >
      <svg
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        class="flex-grow-0 flex-shrink-0 w-6 h-6 relative"
        preserveAspectRatio="none"
      >
        <path
          d="M15.51 5.32003H17.39V2.14003C16.4798 2.04538 15.5652 1.99865 14.65 2.00003C11.93 2.00003 10.07 3.66003 10.07 6.70003V9.32003H7V12.88H10.07V22H13.75V12.88H16.81L17.27 9.32003H13.75V7.05003C13.75 6.00003 14.03 5.32003 15.51 5.32003Z"
          fill="#111827"
        ></path></svg
      ><svg
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        class="flex-grow-0 flex-shrink-0 w-6 h-6 relative"
        preserveAspectRatio="none"
      >
        <path
          d="M17.34 5.46C17.1027 5.46 16.8707 5.53038 16.6733 5.66224C16.476 5.79409 16.3222 5.98151 16.2313 6.20078C16.1405 6.42005 16.1168 6.66133 16.1631 6.89411C16.2094 7.12689 16.3236 7.34071 16.4915 7.50853C16.6593 7.67635 16.8731 7.79064 17.1059 7.83694C17.3387 7.88324 17.5799 7.85948 17.7992 7.76866C18.0185 7.67783 18.2059 7.52402 18.3378 7.32668C18.4696 7.12935 18.54 6.89734 18.54 6.66C18.54 6.34174 18.4136 6.03652 18.1885 5.81147C17.9635 5.58643 17.6583 5.46 17.34 5.46ZM21.94 7.88C21.9206 7.0503 21.7652 6.2294 21.48 5.45C21.2257 4.78313 20.83 4.17928 20.32 3.68C19.8248 3.16743 19.2196 2.77418 18.55 2.53C17.7727 2.23616 16.9508 2.07721 16.12 2.06C15.06 2 14.72 2 12 2C9.28 2 8.94 2 7.88 2.06C7.04915 2.07721 6.22734 2.23616 5.45 2.53C4.78168 2.77665 4.17693 3.16956 3.68 3.68C3.16743 4.17518 2.77418 4.78044 2.53 5.45C2.23616 6.22734 2.07721 7.04915 2.06 7.88C2 8.94 2 9.28 2 12C2 14.72 2 15.06 2.06 16.12C2.07721 16.9508 2.23616 17.7727 2.53 18.55C2.77418 19.2196 3.16743 19.8248 3.68 20.32C4.17693 20.8304 4.78168 21.2234 5.45 21.47C6.22734 21.7638 7.04915 21.9228 7.88 21.94C8.94 22 9.28 22 12 22C14.72 22 15.06 22 16.12 21.94C16.9508 21.9228 17.7727 21.7638 18.55 21.47C19.2196 21.2258 19.8248 20.8326 20.32 20.32C20.8322 19.8226 21.2283 19.2182 21.48 18.55C21.7652 17.7706 21.9206 16.9497 21.94 16.12C21.94 15.06 22 14.72 22 12C22 9.28 22 8.94 21.94 7.88ZM20.14 16C20.1327 16.6348 20.0178 17.2637 19.8 17.86C19.6403 18.2952 19.3839 18.6884 19.05 19.01C18.7256 19.3405 18.3332 19.5964 17.9 19.76C17.3037 19.9778 16.6748 20.0927 16.04 20.1C15.04 20.15 14.67 20.16 12.04 20.16C9.41 20.16 9.04 20.16 8.04 20.1C7.38089 20.1123 6.72459 20.0109 6.1 19.8C5.68578 19.6281 5.31136 19.3728 5 19.05C4.66809 18.7287 4.41484 18.3352 4.26 17.9C4.01586 17.2952 3.88044 16.6519 3.86 16C3.86 15 3.8 14.63 3.8 12C3.8 9.37 3.8 9 3.86 8C3.86448 7.35106 3.98295 6.70795 4.21 6.1C4.38605 5.67791 4.65627 5.30166 5 5C5.30381 4.65617 5.67929 4.3831 6.1 4.2C6.70955 3.98004 7.352 3.86508 8 3.86C9 3.86 9.37 3.8 12 3.8C14.63 3.8 15 3.8 16 3.86C16.6348 3.86728 17.2637 3.98225 17.86 4.2C18.3144 4.36865 18.7223 4.64285 19.05 5C19.3777 5.30718 19.6338 5.68273 19.8 6.1C20.0223 6.70893 20.1373 7.35178 20.14 8C20.19 9 20.2 9.37 20.2 12C20.2 14.63 20.19 15 20.14 16ZM12 6.87C10.9858 6.87198 9.99496 7.17453 9.15265 7.73942C8.31035 8.30431 7.65438 9.1062 7.26763 10.0438C6.88089 10.9813 6.78072 12.0125 6.97979 13.0069C7.17886 14.0014 7.66824 14.9145 8.38608 15.631C9.10392 16.3474 10.018 16.835 11.0129 17.0321C12.0077 17.2293 13.0387 17.1271 13.9755 16.7385C14.9123 16.35 15.7129 15.6924 16.2761 14.849C16.8394 14.0056 17.14 13.0142 17.14 12C17.1413 11.3251 17.0092 10.6566 16.7512 10.033C16.4933 9.40931 16.1146 8.84281 15.6369 8.36605C15.1592 7.88929 14.5919 7.51168 13.9678 7.25493C13.3436 6.99818 12.6749 6.86736 12 6.87ZM12 15.33C11.3414 15.33 10.6976 15.1347 10.15 14.7688C9.60234 14.4029 9.17552 13.8828 8.92348 13.2743C8.67144 12.6659 8.6055 11.9963 8.73398 11.3503C8.86247 10.7044 9.17963 10.111 9.64533 9.64533C10.111 9.17963 10.7044 8.86247 11.3503 8.73398C11.9963 8.6055 12.6659 8.67144 13.2743 8.92348C13.8828 9.17552 14.4029 9.60234 14.7688 10.15C15.1347 10.6976 15.33 11.3414 15.33 12C15.33 12.4373 15.2439 12.8703 15.0765 13.2743C14.9092 13.6784 14.6639 14.0454 14.3547 14.3547C14.0454 14.6639 13.6784 14.9092 13.2743 15.0765C12.8703 15.2439 12.4373 15.33 12 15.33Z"
          fill="#111827"
        ></path></svg
      ><svg
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        class="flex-grow-0 flex-shrink-0 w-6 h-6 relative"
        preserveAspectRatio="none"
      >
        <path
          d="M22 5.9506C21.2483 6.2767 20.4534 6.49226 19.64 6.5906C20.4982 6.07792 21.1413 5.27138 21.45 4.3206C20.6436 4.80066 19.7608 5.1389 18.84 5.3206C18.2245 4.65317 17.405 4.2089 16.5098 4.05745C15.6147 3.90601 14.6945 4.05596 13.8938 4.48379C13.093 4.91162 12.4569 5.59313 12.0852 6.42144C11.7135 7.24974 11.6273 8.17799 11.84 9.0606C10.2094 8.97813 8.61444 8.55355 7.15865 7.81446C5.70287 7.07537 4.41885 6.03829 3.39 4.7706C3.02914 5.40077 2.83952 6.11442 2.84 6.8406C2.83872 7.51498 3.00422 8.17922 3.32176 8.77416C3.63929 9.36911 4.09902 9.87631 4.66 10.2506C4.00798 10.2329 3.36989 10.0579 2.8 9.7406V9.7906C2.80489 10.7355 3.13599 11.6497 3.73731 12.3786C4.33864 13.1074 5.17326 13.6062 6.1 13.7906C5.74326 13.8992 5.37287 13.9564 5 13.9606C4.74189 13.9576 4.48442 13.9342 4.23 13.8906C4.49391 14.7034 5.00462 15.4137 5.69107 15.9228C6.37753 16.4318 7.20558 16.7142 8.06 16.7306C6.6172 17.8659 4.83588 18.4855 3 18.4906C2.66574 18.4917 2.33174 18.4717 2 18.4306C3.87443 19.6409 6.05881 20.2833 8.29 20.2806C9.82969 20.2966 11.3571 20.0056 12.7831 19.4247C14.2091 18.8437 15.505 17.9845 16.5952 16.8971C17.6854 15.8097 18.548 14.516 19.1326 13.0915C19.7172 11.667 20.012 10.1403 20 8.6006C20 8.4306 20 8.2506 20 8.0706C20.7847 7.48541 21.4615 6.76803 22 5.9506Z"
          fill="#111827"
        ></path></svg
      ><svg
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        class="flex-grow-0 flex-shrink-0 w-6 h-6 relative"
        preserveAspectRatio="none"
      >
        <path
          d="M20.41 2.00014H3.47C3.27958 1.9975 3.0905 2.03239 2.91357 2.10282C2.73663 2.17326 2.5753 2.27786 2.4388 2.41065C2.30229 2.54344 2.19328 2.70182 2.11799 2.87675C2.0427 3.05167 2.00261 3.23972 2 3.43014V20.5701C2.00261 20.7606 2.0427 20.9486 2.11799 21.1235C2.19328 21.2985 2.30229 21.4568 2.4388 21.5896C2.5753 21.7224 2.73663 21.827 2.91357 21.8975C3.0905 21.9679 3.27958 22.0028 3.47 22.0001H20.41C20.6004 22.0028 20.7895 21.9679 20.9664 21.8975C21.1434 21.827 21.3047 21.7224 21.4412 21.5896C21.5777 21.4568 21.6867 21.2985 21.762 21.1235C21.8373 20.9486 21.8774 20.7606 21.88 20.5701V3.43014C21.8774 3.23972 21.8373 3.05167 21.762 2.87675C21.6867 2.70182 21.5777 2.54344 21.4412 2.41065C21.3047 2.27786 21.1434 2.17326 20.9664 2.10282C20.7895 2.03239 20.6004 1.9975 20.41 2.00014ZM8.03 18.7401H5.03V9.74014H8.03V18.7401ZM6.53 8.48014C6.11626 8.48014 5.71947 8.31578 5.42691 8.02323C5.13436 7.73067 4.97 7.33388 4.97 6.92014C4.97 6.5064 5.13436 6.10961 5.42691 5.81705C5.71947 5.5245 6.11626 5.36014 6.53 5.36014C6.7497 5.33522 6.97218 5.35699 7.18288 5.42402C7.39357 5.49105 7.58774 5.60183 7.75266 5.7491C7.91757 5.89637 8.04953 6.07682 8.13987 6.27862C8.23022 6.48043 8.27692 6.69904 8.27692 6.92014C8.27692 7.14124 8.23022 7.35985 8.13987 7.56166C8.04953 7.76346 7.91757 7.94391 7.75266 8.09118C7.58774 8.23845 7.39357 8.34923 7.18288 8.41626C6.97218 8.48329 6.7497 8.50505 6.53 8.48014ZM18.85 18.7401H15.85V13.9101C15.85 12.7001 15.42 11.9101 14.33 11.9101C13.9927 11.9126 13.6642 12.0184 13.3888 12.2133C13.1135 12.4082 12.9045 12.6828 12.79 13.0001C12.7117 13.2352 12.6778 13.4827 12.69 13.7301V18.7301H9.69C9.69 18.7301 9.69 10.5501 9.69 9.73014H12.69V11.0001C12.9625 10.5272 13.3589 10.1377 13.8364 9.87334C14.314 9.60902 14.8546 9.47999 15.4 9.50014C17.4 9.50014 18.85 10.7901 18.85 13.5601V18.7401Z"
          fill="#111827"
        ></path>
      </svg>
    </div>
    <p
      class="w-[405.48px] absolute left-[147px] top-[511px] opacity-50 text-base text-left text-gray-900"
    >
      ©2021 Estatery. All rights reserved
    </p>
  </div>
  <svg
    width="1280"
    height="2"
    viewBox="0 0 1280 2"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    class="absolute left-[-1.25px] top-[477.75px]"
    preserveAspectRatio="xMidYMid meet"
  >
    <line y1="1.25" x2="1280" y2="1.25" stroke="#E0E7FF" stroke-width="1.5"></line>
  </svg>
  <div class="flex justify-start items-start w-[928px] absolute left-[335px] top-[79px] gap-8">
    <div class="flex flex-col justify-start items-start flex-grow relative gap-12">
      <div class="flex-grow-0 flex-shrink-0 w-[200px] h-[136px]">
        <p class="w-[200px] absolute left-0 top-10 opacity-70 text-base text-left text-gray-500">
          <span class="w-[200px] opacity-70 text-base text-left text-gray-500"
            >Request an offer</span
          ><br /><span class="w-[200px] opacity-70 text-base text-left text-gray-500">Pricing</span
          ><br /><span class="w-[200px] opacity-70 text-base text-left text-gray-500">Reviews</span
          ><br /><span class="w-[200px] opacity-70 text-base text-left text-gray-500">Stories</span>
        </p>
        <p class="absolute left-0 top-0 text-base font-bold text-left text-gray-900">SELL A HOME</p>
      </div>
      <div class="flex-grow-0 flex-shrink-0 w-[200px] h-[88px]">
        <p class="w-[200px] absolute left-0 top-56 opacity-70 text-base text-left text-gray-500">
          <span class="w-[200px] opacity-70 text-base text-left text-gray-500">Buy</span><br /><span
            class="w-[200px] opacity-70 text-base text-left text-gray-500"
            >Finance</span
          >
        </p>
        <p class="absolute left-0 top-[184px] text-base font-bold text-left text-gray-900">
          BUY A HOME
        </p>
      </div>
    </div>
    <div class="flex flex-col justify-start items-start flex-grow relative gap-12">
      <div class="flex-grow-0 flex-shrink-0 w-[200px] h-28">
        <p class="w-[200px] absolute left-0 top-10 opacity-70 text-base text-left text-gray-500">
          <span class="w-[200px] opacity-70 text-base text-left text-gray-500"
            >Buy and sell properties</span
          ><br /><span class="w-[200px] opacity-70 text-base text-left text-gray-500"
            >Rent home</span
          ><br /><span class="w-[200px] opacity-70 text-base text-left text-gray-500"
            >Builder trade-up</span
          >
        </p>
        <p class="absolute left-0 top-0 text-base font-bold text-left text-gray-900">
          BUY, RENT AND SELL
        </p>
      </div>
      <div class="flex-grow-0 flex-shrink-0 w-[200px] h-28">
        <p
          class="w-[200px] absolute left-0 top-[200px] opacity-70 text-base text-left text-gray-500"
        >
          <span class="w-[200px] opacity-70 text-base text-left text-gray-500"
            >Trust &#x26; Safety</span
          ><br /><span class="w-[200px] opacity-70 text-base text-left text-gray-500"
            >Terms of Service</span
          ><br /><span class="w-[200px] opacity-70 text-base text-left text-gray-500"
            >Privacy Policy</span
          >
        </p>
        <p class="absolute left-0 top-40 text-base font-bold text-left text-gray-900">
          TERMS &#x26; PRIVACY
        </p>
      </div>
    </div>
    <div class="flex flex-col justify-start items-start flex-grow relative gap-12">
      <div class="flex-grow-0 flex-shrink-0 w-[200px] h-[136px]">
        <p class="w-[200px] absolute left-0 top-10 opacity-70 text-base text-left text-gray-500">
          <span class="w-[200px] opacity-70 text-base text-left text-gray-500">Company</span
          ><br /><span class="w-[200px] opacity-70 text-base text-left text-gray-500"
            >How it works</span
          ><br /><span class="w-[200px] opacity-70 text-base text-left text-gray-500">Contact</span
          ><br /><span class="w-[200px] opacity-70 text-base text-left text-gray-500"
            >Investors</span
          >
        </p>
        <p class="absolute left-0 top-0 text-base font-bold text-left text-gray-900">ABOUT</p>
      </div>
      <div class="flex-grow-0 flex-shrink-0 w-[200px] h-[136px]">
        <p class="w-[200px] absolute left-0 top-56 opacity-70 text-base text-left text-gray-500">
          <span class="w-[200px] opacity-70 text-base text-left text-gray-500">Blog</span
          ><br /><span class="w-[200px] opacity-70 text-base text-left text-gray-500">Guides</span
          ><br /><span class="w-[200px] opacity-70 text-base text-left text-gray-500">FAQ</span
          ><br /><span class="w-[200px] opacity-70 text-base text-left text-gray-500"
            >Help Center</span
          >
        </p>
        <p class="absolute left-0 top-[184px] text-base font-bold text-left text-gray-900">
          RESOURCES
        </p>
      </div>
    </div>
  </div>
  <div class="w-[151px] h-10 absolute left-[15px] top-[79px] overflow-hidden">
    <p class="absolute left-11 top-[9px] text-xl font-bold text-left text-gray-900">Estatery</p>
    <svg
      width="32"
      height="32"
      viewBox="0 0 32 32"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      class="w-8 h-8 absolute left-[7px] top-[3px]"
      preserveAspectRatio="xMidYMid meet"
    >
      <path
        d="M25.3335 11.6137L18.2229 6.08301C17.5989 5.59755 16.8308 5.33398 16.0402 5.33398C15.2496 5.33398 14.4816 5.59755 13.8575 6.08301L6.74554 11.6137C6.31813 11.9461 5.97233 12.3717 5.73454 12.8581C5.49676 13.3446 5.37328 13.8789 5.37354 14.4203V24.0203C5.37354 24.7276 5.65449 25.4059 6.15458 25.906C6.65468 26.4061 7.33296 26.687 8.0402 26.687H24.0402C24.7474 26.687 25.4257 26.4061 25.9258 25.906C26.4259 25.4059 26.7069 24.7276 26.7069 24.0203V14.4203C26.7069 13.323 26.2002 12.287 25.3335 11.6137Z"
        fill="#6366F1"
        stroke="#6366F1"
        stroke-width="3"
        stroke-linecap="round"
        stroke-linejoin="round"
      ></path>
      <path
        d="M21.3332 20C18.3865 21.7773 13.6105 21.7773 10.6665 20"
        stroke="white"
        stroke-width="3"
        stroke-linecap="round"
        stroke-linejoin="round"
      ></path>
    </svg>
  </div>
  </div>
</footer>
</template>