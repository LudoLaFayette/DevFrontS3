<template>
    <svg
  width="2048"
  height="2"
  viewBox="0 0 2048 2"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
  preserveAspectRatio="xMidYMid meet"
>
  <line y1="1.25" x2="2048" y2="1.25" stroke="#E0E7FF" stroke-width="1.5"></line>
</svg>

</template>