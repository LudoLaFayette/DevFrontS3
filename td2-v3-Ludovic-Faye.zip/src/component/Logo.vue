<template>
  <div class="flex items-center justify-center">
    <div class="flex w-[151px] overflow-hidden">      
        <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" class="flex h-8 w-8 " preserveAspectRatio="xMidYMid meet">
          <path
            d="M25.3335 11.6137L18.2229 6.08304C17.5989 5.59758 16.8308 5.33401 16.0402 5.33401C15.2496 5.33401 14.4815 5.59758 13.8575 6.08304L6.74554 11.6137C6.31813 11.9461 5.97233 12.3717 5.73454 12.8582C5.49676 13.3446 5.37328 13.8789 5.37354 14.4204V24.0204C5.37354 24.7276 5.65449 25.4059 6.15458 25.906C6.65468 26.4061 7.33296 26.687 8.0402 26.687H24.0402C24.7474 26.687 25.4257 26.4061 25.9258 25.906C26.4259 25.4059 26.7069 24.7276 26.7069 24.0204V14.4204C26.7069 13.323 26.2002 12.287 25.3335 11.6137Z"
            fill="#6366F1"
            stroke="#6366F1"
            stroke-width="3"
            stroke-linecap="round"
            stroke-linejoin="round"
          ></path>
          <path d="M21.3332 20C18.3865 21.7774 13.6105 21.7774 10.6665 20" stroke="white" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"></path>
        </svg>
      <div class="flex">
        <p class="flex text-xl font-bold items-center text-gray-900">Estatery</p>
      </div>      
    </div>
  </div>
</template>