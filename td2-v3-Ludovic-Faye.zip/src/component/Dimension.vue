<template>
    <svg
  width="20"
  height="20"
  viewBox="0 0 20 20"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
  class="flex-grow-0 flex-shrink-0 w-5 h-5 relative"
  preserveAspectRatio="none"
>
  <path
    d="M8.83161 15.5436L3.45643 10.1684C2.84802 9.56002 2.84802 8.4398 3.45643 7.83139L8.83161 2.45621C9.44001 1.84781 10.5602 1.84781 11.1686 2.45621L16.5438 7.83139C17.1522 8.4398 17.1522 9.56002 16.5438 10.1684L11.1686 15.5436C10.5602 16.152 9.44001 16.152 8.83161 15.5436V15.5436Z"
    stroke="#6366F1"
    stroke-width="1.66667"
    stroke-linecap="round"
    stroke-linejoin="round"
  ></path>
  <path
    d="M1.99988 13.1716L6.36359 17.5353"
    stroke="#6366F1"
    stroke-width="1.66667"
    stroke-linecap="round"
    stroke-linejoin="round"
  ></path>
  <path
    d="M13.6361 17.5353L17.9998 13.1716"
    stroke="#6366F1"
    stroke-width="1.66667"
    stroke-linecap="round"
    stroke-linejoin="round"
  ></path>
</svg>
</template>