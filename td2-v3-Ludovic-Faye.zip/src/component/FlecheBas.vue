<template>
<svg
  width="12"
  height="12"
  viewBox="0 0 12 12"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
  class="w-6 h-6 "
  preserveAspectRatio="xMidYMid meet"
>
  <path
    d="M2.5 4.25L6 7.75L9.5 4.25"
    stroke="#6366F1"
    stroke-width="2"
    stroke-linecap="round"
    stroke-linejoin="round"
  ></path>
</svg>
</template>